package ifpb.aps.ws.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ifpb.aps.ws.model.MonitorDisciplina;
import ifpb.aps.ws.service.MonitorDisciplinaService;

@RestController
@RequestMapping("/monitorDisciplina")
public class MonitorDisciplinaController {

	@Autowired
	private MonitorDisciplinaService monitorDisciplinaService;

	@GetMapping
	public List<MonitorDisciplina> listarMonitoresDisciplinas() {
		return monitorDisciplinaService.listarMonitoresDisciplinas();
	}

	@PostMapping
	public MonitorDisciplina cadastrarMonitorDisciplina(@RequestBody MonitorDisciplina monitor) {
		return monitorDisciplinaService.cadastrarMonitorDisciplina(monitor);
	}

	@PutMapping
	public MonitorDisciplina atualizarMonitorDisciplina(@RequestBody MonitorDisciplina monitor) {
		return monitorDisciplinaService.atualizarMonitorDisciplina(monitor);
	}

	@DeleteMapping
	public Long deletarMonitorDisciplina(@RequestBody MonitorDisciplina monitor) {
		return monitorDisciplinaService.deletarMonitorDisciplina(monitor);
	}

}
