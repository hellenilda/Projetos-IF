package ifpb.aps.ws.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ifpb.aps.ws.model.MonitorDisciplina;

public interface MonitorDisciplinaRepository extends JpaRepository<MonitorDisciplina, Long> {

}
