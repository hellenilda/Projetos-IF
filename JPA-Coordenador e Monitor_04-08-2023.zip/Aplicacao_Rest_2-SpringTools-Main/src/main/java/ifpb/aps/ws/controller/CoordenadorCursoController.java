package ifpb.aps.ws.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ifpb.aps.ws.model.CoordenadorCurso;
import ifpb.aps.ws.service.CoordenadorCursoService;

@RestController
@RequestMapping("/coordenadorCurso")
public class CoordenadorCursoController {

	@Autowired
	private CoordenadorCursoService coordenadorCursoService;

	@GetMapping
	public List<CoordenadorCurso> listarCoordenadoresCursos() {
		return coordenadorCursoService.listarCoordenadoresCursos();
	}

	@PostMapping
	public CoordenadorCurso cadastrarCoordenadorCurso(@RequestBody CoordenadorCurso coordenador) {
		return coordenadorCursoService.cadastrarCoordenadorCurso(coordenador);
	}

	@PutMapping
	public CoordenadorCurso atualizarCoordenadorCurso(@RequestBody CoordenadorCurso coordenador) {
		return coordenadorCursoService.atualizarCoordenadorCurso(coordenador);
	}

	@DeleteMapping
	public Long deletarCoordenadorCurso(@RequestBody CoordenadorCurso coordenador) {
		return coordenadorCursoService.deletarCoordenadorCurso(coordenador);
	}
}
