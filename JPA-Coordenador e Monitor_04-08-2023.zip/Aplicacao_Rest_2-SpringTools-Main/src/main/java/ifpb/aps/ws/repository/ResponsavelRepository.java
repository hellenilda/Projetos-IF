package ifpb.aps.ws.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ifpb.aps.ws.model.Responsavel;

public interface ResponsavelRepository extends JpaRepository<Responsavel, Long>{

}