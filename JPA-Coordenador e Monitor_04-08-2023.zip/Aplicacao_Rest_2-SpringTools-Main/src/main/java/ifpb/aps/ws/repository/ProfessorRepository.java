package ifpb.aps.ws.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ifpb.aps.ws.model.Professor;

public interface ProfessorRepository extends JpaRepository<Professor, Long>{

}
