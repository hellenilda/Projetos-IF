package ifpb.aps.ws.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ifpb.aps.ws.model.CoordenadorCurso;
import ifpb.aps.ws.repository.CoordenadorCursoRepository;

@Service
public class CoordenadorCursoService {
	@Autowired
	private CoordenadorCursoRepository coordenadorCursoRepository;

	public List<CoordenadorCurso> listarCoordenadoresCursos() {
		return coordenadorCursoRepository.findAll();
	}

	public CoordenadorCurso cadastrarCoordenadorCurso(CoordenadorCurso cordenador) {
		return coordenadorCursoRepository.save(cordenador);
	}

	public CoordenadorCurso atualizarCoordenadorCurso(CoordenadorCurso cordenador) {
		return coordenadorCursoRepository.save(cordenador);
	}

	public Long deletarCoordenadorCurso(CoordenadorCurso cordenadorRequest) {
		coordenadorCursoRepository.deleteById(cordenadorRequest.getMatricula());
		return (long) 0;
	}
}
