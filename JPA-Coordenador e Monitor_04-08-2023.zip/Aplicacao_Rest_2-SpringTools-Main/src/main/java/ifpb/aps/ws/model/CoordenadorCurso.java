package ifpb.aps.ws.model;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="CoordenadorCurso")
public class CoordenadorCurso {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="coordenador_seq")
	@SequenceGenerator(name="coordenador_seq", sequenceName="coordenador_seq", allocationSize=1)
	private Long matricula;
	
	@Column
	private String nome;
	
	@Column
	private String area_atuacao;

	@Column
	public long getMatricula() {
		return matricula;
	}

	public void setMatricula(Long matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getArea_atuacao() {
		return area_atuacao;
	}

	public void setArea_atuacao(String area_atuacao) {
		this.area_atuacao = area_atuacao;
	}

	@Override
	public int hashCode() {
		return Objects.hash(area_atuacao, matricula, nome);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CoordenadorCurso other = (CoordenadorCurso) obj;
		return Objects.equals(area_atuacao, other.area_atuacao) && matricula == other.matricula
				&& Objects.equals(nome, other.nome);
	}
}