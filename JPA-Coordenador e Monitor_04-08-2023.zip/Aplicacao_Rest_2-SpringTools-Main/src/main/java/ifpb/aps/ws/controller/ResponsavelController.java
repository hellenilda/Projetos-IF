package ifpb.aps.ws.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ifpb.aps.ws.model.Responsavel;
import ifpb.aps.ws.service.ResponsavelService;

@RestController
@RequestMapping("/alunos")
public class ResponsavelController {
	
	@Autowired
	private ResponsavelService responsavelService;
	
	@GetMapping
	public List<Responsavel> listarResponsaveis() {
		return responsavelService.listarResponsaveis();
	}
	
	@PostMapping
	public Responsavel cadastrarResponsavel(@RequestBody Responsavel responsavel) {
		return responsavelService.cadastrarResponsavel(responsavel);
	}
	
	@PutMapping
	public Responsavel atualizarResponsavel(@RequestBody Responsavel responsavel) {
		return responsavelService.atualizarResponsavel(responsavel);
	}
	
	@DeleteMapping
	public Long deletarResponsavel(@RequestBody Responsavel responsavel) {
		return responsavelService.deletarResponsavel(responsavel);
	}
}
