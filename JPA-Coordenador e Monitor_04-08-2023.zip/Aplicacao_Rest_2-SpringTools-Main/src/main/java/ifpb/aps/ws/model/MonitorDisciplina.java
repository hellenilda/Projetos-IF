package ifpb.aps.ws.model;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="MonitorDisciplina")
public class MonitorDisciplina {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="monitor_seq")
	@SequenceGenerator(name="monitor_seq", sequenceName="monitor_seq", allocationSize = 1)
	private Long matricula;
	
	@Column
	private String nome;
	
	@Column
	private String disciplina_monitorada;

	@Column
	public Long getMatricula() {
		return matricula;
	}

	public void setMatricula(Long matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDisciplina_monitorada() {
		return disciplina_monitorada;
	}

	public void setDisciplina_monitorada(String disciplina_monitorada) {
		this.disciplina_monitorada = disciplina_monitorada;
	}

	@Override
	public int hashCode() {
		return Objects.hash(disciplina_monitorada, matricula, nome);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MonitorDisciplina other = (MonitorDisciplina) obj;
		return Objects.equals(disciplina_monitorada, other.disciplina_monitorada)
				&& Objects.equals(matricula, other.matricula) && Objects.equals(nome, other.nome);
	}
}