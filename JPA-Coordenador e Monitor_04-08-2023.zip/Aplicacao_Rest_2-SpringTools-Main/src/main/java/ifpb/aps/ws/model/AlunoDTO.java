package ifpb.aps.ws.model;

public interface AlunoDTO {
	
	String getNome();
	String getMatricula();
}
