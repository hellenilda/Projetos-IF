package edu.ifpb.webII.model.service;

public class UsuarioService {

}
