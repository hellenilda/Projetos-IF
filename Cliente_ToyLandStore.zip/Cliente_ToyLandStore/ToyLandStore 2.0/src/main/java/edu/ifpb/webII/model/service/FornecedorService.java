package edu.ifpb.webII.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.ifpb.webII.model.Fornecedor;
import edu.ifpb.webII.repository.FornecedorRepository;

@Service
public class FornecedorService {
	
	@Autowired
	private FornecedorRepository fornecedorRepository;

	public List<Fornecedor> listarFornecedor() {
		return fornecedorRepository.findAll();
	}

	public Fornecedor cadastrarFornecedor(Fornecedor fornecedor) {
		return fornecedorRepository.save(fornecedor);
	}

	public Fornecedor atualizarFornecedor(Fornecedor fornecedor) {
		return fornecedorRepository.save(fornecedor);
	}

	public Fornecedor listarFornecedor(Long id) {
		Fornecedor fornecedor = (Fornecedor) fornecedorRepository.findById(id).orElse(null);
		return fornecedor;
	}

	public String deletarFornecedor(Long id) {
		fornecedorRepository.deleteById(id);
		return "Fornecedor de id " + id + " deletado com sucesso!";
	}
}
