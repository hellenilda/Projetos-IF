package edu.ifpb.webII.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import edu.ifpb.webII.model.Fornecedor;
import edu.ifpb.webII.model.service.FornecedorService;

@Controller
@RequestMapping("/fornecedores")
public class FornecedorController {
	
	@Autowired
	private FornecedorService fornecedorService;
	
	@GetMapping("/cadastrar")
	public String cadastrar(Fornecedor fornecedor, ModelMap model) {
		List<Fornecedor> fornecedores = fornecedorService.listarFornecedor();
		model.addAttribute("fornecedores", fornecedores);
		return "/fornecedores/cadastroFornecedor";
	}
	
	@PostMapping("/salvar")
	public String salvar(Fornecedor fornecedor, RedirectAttributes attr) {
		if (fornecedor.getId() == null) {
			fornecedorService.cadastrarFornecedor(fornecedor);
		} else {
			fornecedorService.atualizarFornecedor(fornecedor);
		}
		attr.addFlashAttribute("sucesso", "Fornecedor salvo com sucesso!");
		return "redirect:/fornecedores/cadastrar";
	}
	
	@GetMapping("listar")
	public String listar(ModelMap model) {
		List<Fornecedor> fornecedores = fornecedorService.listarFornecedor();
		model.addAttribute("fornecedores", fornecedores);
		return "/fornecedores/listaFornecedor";
	}
	
	@GetMapping("/editar")
	public String editar(Fornecedor fornecedor, RedirectAttributes attr) {
		fornecedorService.atualizarFornecedor(fornecedor);
		attr.addFlashAttribute("sucesso", "Fornecedor editado com sucesso!");
		return "redirect:/fornecedores/cadastrar";
	}
	
	@GetMapping("excluir/{id}")
	public String excluir(@PathVariable("id") Long id, ModelMap model) {
		fornecedorService.deletarFornecedor(id);
		model.addAttribute("sucesso", "Fornecedor excluído com sucesso!");
		return listar(model);
	}
}
