package ifpb.aps.ws.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ifpb.aps.ws.model.CoordenadorCurso;

public interface CoordenadorCursoRepository extends JpaRepository<CoordenadorCurso, Long> {

}
