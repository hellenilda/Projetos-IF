package ifpb.aps.ws.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ifpb.aps.ws.model.Responsavel;
import ifpb.aps.ws.repository.ResponsavelRepository;

@Service
public class ResponsavelService {

	@Autowired
	private ResponsavelRepository responsavelRepository;
	
	public List<Responsavel> listarResponsaveis() {
		return responsavelRepository.findAll();
	}
	
	public Responsavel cadastrarResponsavel(Responsavel responsavel) {
		return responsavelRepository.save(responsavel);
	}
	
	public Responsavel atualizarResponsavel(Responsavel responsavel) {
		return responsavelRepository.save(responsavel);
	}
	
	public Long deletarResponsavel(Responsavel responsavelrequest) {
		responsavelRepository.deleteById(
				responsavelrequest.getId_responsavel());
		return (long) 0;
	}
}
