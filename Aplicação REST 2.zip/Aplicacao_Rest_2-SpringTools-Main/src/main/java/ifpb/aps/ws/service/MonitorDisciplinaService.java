package ifpb.aps.ws.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ifpb.aps.ws.model.MonitorDisciplina;
import ifpb.aps.ws.repository.MonitorDisciplinaRepository;

@Service
public class MonitorDisciplinaService {
	
	@Autowired
	private MonitorDisciplinaRepository monitorDisciplinaRepository;

	public List<MonitorDisciplina> listarMonitoresDisciplinas() {
		return monitorDisciplinaRepository.findAll();
	}

	public MonitorDisciplina cadastrarMonitorDisciplina(MonitorDisciplina monitor) {
		return monitorDisciplinaRepository.save(monitor);
	}

	public MonitorDisciplina atualizarMonitorDisciplina(MonitorDisciplina monitor) {
		return monitorDisciplinaRepository.save(monitor);
	}

	public Long deletarMonitorDisciplina(MonitorDisciplina monitorRequest) {
		monitorDisciplinaRepository.deleteById(monitorRequest.getMatricula());
		return (long) 0;
	}

}
