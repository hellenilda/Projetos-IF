package edu.ifpb.webII.security;

import org.springframework.beans.factory.annotation.Autowired;

import edu.ifpb.webII.model.Usuario;
import edu.ifpb.webII.repository.UsuarioRepository;

/*INCOMPLETO*/

public class CustomUserDetailsService {
	
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	public CustomUserDetailsService(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}

	/*
	 * @Override public UserDetais loadUserByUsername(String email) throws
	 * UsernameNotFoundException { Usuario usuario =
	 * usuarioRepository.findByEmail(email);
	 * 
	 * if (usuario != null) { return new
	 * org.springframework.core.userdetails.User(usuario.getEmail(),
	 * usuario.getSenha(), mapRolesToAuthorities(usuario.getRoles())) } else { throw
	 * new UsernameNotFoundException("Nome de usuário ou senha inválidos.") } }
	 */
	
	public void mapRolesToAuthorities(){
		
	}

}