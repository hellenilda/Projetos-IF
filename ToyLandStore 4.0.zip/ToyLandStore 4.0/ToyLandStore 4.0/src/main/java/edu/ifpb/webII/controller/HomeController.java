package edu.ifpb.webII.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HomeController {
	
	@GetMapping("/")
	public String home() {
		return "/home";
	}
	
	@GetMapping("/login")
	public String login() {
		return "/login";
	}
	
	@GetMapping("/cadastro")
	public String cadastro() {
		return "/cadastro";
	}
	
	@PostMapping("/cadastro/salvar")
	public String salvarCadastro() {
		return "/cadastro/salvar";
	}
}
