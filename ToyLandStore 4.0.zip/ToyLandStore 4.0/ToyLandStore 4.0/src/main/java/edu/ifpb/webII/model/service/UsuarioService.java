package edu.ifpb.webII.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.ifpb.webII.model.Usuario;
import edu.ifpb.webII.repository.RoleRepository;
import edu.ifpb.webII.repository.UsuarioRepository;

/*INCOMPLETO*/

@Service
public class UsuarioService {
	
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	/* passwordEncoder */
	
	public Usuario cadastrarUsuario(Usuario usuario) {
		return usuarioRepository.save(usuario);
	}
	
	public List<Usuario> findAllUsers() {
		return usuarioRepository.findAll();
	}
}
