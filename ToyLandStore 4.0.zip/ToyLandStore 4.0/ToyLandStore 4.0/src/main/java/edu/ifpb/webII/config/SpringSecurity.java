package edu.ifpb.webII.config;

import org.springframework.beans.factory.annotation.Autowired;

import edu.ifpb.webII.security.CustomUserDetailsService;

/*INCOMPLETO*/

public class SpringSecurity {
	
	@Autowired
	private CustomUserDetailsService userDetailsService;
	
	
}
