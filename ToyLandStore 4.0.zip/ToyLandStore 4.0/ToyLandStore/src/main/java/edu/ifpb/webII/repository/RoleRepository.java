package edu.ifpb.webII.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.ifpb.webII.model.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Role findByNome(String nome);
}