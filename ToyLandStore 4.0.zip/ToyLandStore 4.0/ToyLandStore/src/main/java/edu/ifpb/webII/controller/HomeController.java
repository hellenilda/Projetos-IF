package edu.ifpb.webII.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import edu.ifpb.webII.model.Usuario;
import edu.ifpb.webII.model.service.UsuarioService;

@Controller
@RequestMapping("/")
public class HomeController {

	private UsuarioService usuarioService;

    public HomeController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

	@GetMapping("/")
	public String home() {
		return "/home";
	}

	
	 @GetMapping("/login")
	 public String login() {
		 return "/login";
	 }
	 
    @GetMapping("/cadastro")
    public String cadastro(Model model){
        Usuario usuario = new Usuario();
        model.addAttribute("usuario", usuario);
        return "/cadastro";
    }

    @PostMapping("/cadastro/salvar")
    public String salvarCadastro(@ModelAttribute("usuario") Usuario usuario,
                               BindingResult result,
                               Model model){
        Usuario existing = usuarioService.findByEmail(usuario.getEmail());
        if (existing != null) {
            result.rejectValue("email", null, "Já exite uma conta registrada com esse email.");
        }
        if (result.hasErrors()) {
            model.addAttribute("usuario", usuario);
            return "cadastro";
        }
        usuarioService.saveUser(usuario);
        return "redirect:/cadastro?success";
    }
    
    @GetMapping("/recuperar")
    public String recuperarSenha(Model model){
        Usuario usuario = new Usuario();
        model.addAttribute("usuario", usuario);
        return "/recuperarEmail";
    }
    
    @PostMapping("/recuperar/email")
    public String recuperarSenhaEmail(@ModelAttribute("usuario") Usuario usuario,
                               BindingResult result,
                               Model model){
        Usuario existing = usuarioService.findByEmail(usuario.getEmail());
        if (existing == null) {
            result.rejectValue("email", null, "Esse email não é cadastrado no sistema.");
        }
        if (result.hasErrors()) {
            model.addAttribute("usuario", usuario);
            return "redirect:/recuperar?error";
        }

        usuarioService.sendEmail(usuario);
        return "redirect:/recuperar?success";
    }
    
    @GetMapping("/senha")
    public String mostrarFormularioAlterarSenha(@RequestParam("email") String email, Model model){
    	Usuario usuario = usuarioService.findByEmail(email);
        model.addAttribute("usuario", usuario);
        return "/alterarSenha";
    }
    
    @PostMapping("/senha/alterar")
    public String alterarSenha(@ModelAttribute("usuario") Usuario usuario_form){
    	Usuario usuario = usuarioService.findByEmail(usuario_form.getEmail());
    	usuario.setSenha(usuario_form.getSenha());
        usuarioService.updateUser(usuario);
        return "redirect:/senha?email=" + usuario.getEmail() + "&success";
    }
}