package edu.ifpb.webII.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import edu.ifpb.webII.model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
	
}
