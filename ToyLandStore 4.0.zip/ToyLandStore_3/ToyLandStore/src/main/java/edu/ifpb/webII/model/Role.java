package edu.ifpb.webII.model;

public class Role {

	private long id;

	private String nome;

	private Usuario usuarios;

	public Role(long id, String nome, Usuario usuarios) {
		super();
		this.id = id;
		this.nome = nome;
		this.usuarios = usuarios;

	}

	public Role() {
		super();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Usuario getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(Usuario usuarios) {
		this.usuarios = usuarios;
	}

}