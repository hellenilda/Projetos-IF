-- Tabela Cliente
CREATE TABLE Cliente (
    id SERIAL PRIMARY KEY,
    cpf VARCHAR(14),
    nome VARCHAR(100),
    cidade VARCHAR(80),
    rua VARCHAR(80),
    numero INTEGER,
    bairro VARCHAR(40),
    estado VARCHAR(80),
    cep VARCHAR(8)
);

-- Tabela Fornecedor
CREATE TABLE Fornecedor (
    id SERIAL PRIMARY KEY,
    cnpj VARCHAR(14),
    nome VARCHAR(80),
    cidade VARCHAR(80),
    rua VARCHAR(80),
    numero INTEGER,
    bairro VARCHAR(40),
    estado VARCHAR(80),
    cep VARCHAR(8)
);

-- Tabela Produto
CREATE TABLE Produto (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    marca VARCHAR(80),
    categoria VARCHAR(80),
    preco NUMERIC(10, 2),
    fornecedor_id INTEGER REFERENCES Fornecedor(id)
);

-- Tabelas de Usuários e Funções
CREATE TABLE Users (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(100),
    senha VARCHAR(80)
);

CREATE TABLE Roles (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(80),
    usuarios VARCHAR(100)
);

-- Sequências
CREATE SEQUENCE cliente_seq
 START WITH     1
 INCREMENT BY   1
 NO CYCLE;

CREATE SEQUENCE produto_seq
 START WITH     1
 INCREMENT BY   1
 NO CYCLE;

CREATE SEQUENCE fornecedor_seq
 START WITH     1
 INCREMENT BY   1
 NO CYCLE;

CREATE SEQUENCE users_seq
 START WITH     1
 INCREMENT BY   1
 NO CYCLE;
