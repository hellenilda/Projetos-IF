package edu.ifpb.webII.model.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import edu.ifpb.webII.model.Role;
import edu.ifpb.webII.model.Usuario;
import edu.ifpb.webII.repository.RoleRepository;
import edu.ifpb.webII.repository.UsuarioRepository;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.mail.SimpleMailMessage;

@Service
public class UsuarioService {

//	@Autowired
//	private JavaMailSender mailSender;

	private UsuarioRepository usuarioRepository;
	private RoleRepository roleRepository;
	private PasswordEncoder passwordEncoder;

	public UsuarioService(UsuarioRepository usuarioRepository, RoleRepository roleRepository,
			PasswordEncoder passwordEncoder) {

		this.usuarioRepository = usuarioRepository;
		this.roleRepository = roleRepository;
		this.passwordEncoder = passwordEncoder;
	}

	public void saveUser(Usuario usuario) {

		usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
		Role role = roleRepository.findByNome("ROLE_ADMIN");
		if (role == null) {
			role = checkRoleExist();

		}
		usuario.setRoles(Arrays.asList(role));
		usuarioRepository.save(usuario);
	}

	public void updateUser(Usuario usuario) {
		usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
		usuarioRepository.updateUser(usuario.getEmail(), usuario.getSenha());
	}

	public Usuario findByEmail(String email) {
		return usuarioRepository.findByEmail(email);
	}

	public List<Usuario> findAllUsers() {
		List<Usuario> usuarios = usuarioRepository.findAll();
		return usuarios.stream().collect(Collectors.toList());
	}

	public void sendEmail(Usuario usuario) {

		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(usuario.getEmail());
		message.setSubject("Recuperação de Senha");
		message.setText("Olá, prezado!\n\n" + "Você está recebendo esse email " + "para recuperar a sua senha. \n\n"
				+ "Clique em: " + "http://localhost:8080/senha?email=" + usuario.getEmail()
				+ "\n\nCaso não tenha solicitado essa ação, " + "por favor desconsiderar esse email.\n\n"
				+ "Atenciosamente,\n" + "Equipe da ToyLand Store");

//		mailSender.send(message);

	}

	private Role checkRoleExist() {
		Role role = new Role();
		role.setNome("ROLE_ADMIN");
		return roleRepository.save(role);
	}

}