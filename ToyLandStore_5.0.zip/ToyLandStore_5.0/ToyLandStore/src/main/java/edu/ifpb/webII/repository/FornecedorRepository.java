package edu.ifpb.webII.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.ifpb.webII.model.Fornecedor;

public interface FornecedorRepository extends JpaRepository<Fornecedor,Long> {

}
