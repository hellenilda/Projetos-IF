package modelo;

public class Professor extends Funcionario{
	private String nome;
	private String materia;
	private int id;
	private long matricula;

	public Professor() {
		super();
	}

	public Professor(String nome, String materia, int id, long matricula) {
		super();
		this.nome = nome;
		this.materia = materia;
		this.id = id;
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getMateria() {
		return materia;
	}

	public void setMateria(String materia) {
		this.materia = materia;
	}

	public long getMatricula() {
		return matricula;
	}

	public void setMatricula(long matricula) {
		this.matricula = matricula;
	}
	
	public void trabalho() {
		System.out.println("Dar aulas");
	}

	@Override
	public String toString() {
		return "Professor [nome=" + nome + ", materia=" + materia + ", id=" + id + ", matricula=" + matricula + "]";
	}

}