package modelo;

public class Aluno {
	private String nome;
	private String curso;
	private int serie;
	private int id;
	private long matricula;

	public Aluno() {
		super();
	}
	
	//Dois métodos "Aluno" utilizando o polimorfismo estático
	public Aluno(String nome, String curso, int serie, int id, long matricula) {
		super();
		this.nome = nome;
		this.curso = curso;
		this.serie = serie;
		this.id = id;
		this.matricula = matricula;
	}
	
	public Aluno(String nome, int serie, int id, long matricula) {
		this.nome = nome;
		this.serie = serie;
		this.id = id;
		this.matricula = matricula;
		this.curso = "Edficacoes";
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public int getSerie() {
		return serie;
	}

	public void setSerie(int serie) {
		this.serie = serie;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getMatricula() {
		return matricula;
	}

	public void setMatricula(long matricula) {
		this.matricula = matricula;
	}

	@Override
	public String toString() {
		return "Aluno [nome=" + nome + ", curso=" + curso + ", serie=" + serie + ", id=" + id + ", matricula="
				+ matricula + "]";
	}

}