package modelo;

public class RegistroDeAula {
	private String conteudo;
	private String data;

	public RegistroDeAula() {
		super();
	}

	public RegistroDeAula(String conteudo, String data) {
		super();
		this.conteudo = conteudo;
		this.data = data;
	}

	public String getConteudo() {
		return conteudo;
	}

	public void setConteudo(String conteudo) {
		this.conteudo = conteudo;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "RegistroDeAula [conteudo=" + conteudo + ", data=" + data + "]";
	}

}