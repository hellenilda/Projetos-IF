package modelo;

public class Diario {
	private String aluno;
	private String professorResponsavel;
	private int numDeFaltas;
	private int nota1;
	private int nota2;
	private int nota3;
	private String data;

	public Diario() {
		super();
	}

	public Diario(String aluno, String professorResponsavel, int numDeFaltas, int nota1, int nota2, int nota3, String data) {
		super();
		this.aluno = aluno;
		this.professorResponsavel = professorResponsavel;
		this.numDeFaltas = numDeFaltas;
		this.nota1 = nota1;
		this.nota2 = nota2;
		this.nota3 = nota3;
		this.data = data;
	}

	public String getAluno() {
		return aluno;
	}

	public void setAluno(String aluno) {
		this.aluno = aluno;
	}

	public String getProfessorResponsavel() {
		return professorResponsavel;
	}

	public void setProfessorResponsavel(String professorResponsavel) {
		this.professorResponsavel = professorResponsavel;
	}

	public int getNumDeFaltas() {
		return numDeFaltas;
	}

	public void setNumDeFaltas(int numDeFaltas) {
		this.numDeFaltas = numDeFaltas;
	}

	public int getNota1() {
		return nota1;
	}

	public void setNota1(int nota1) {
		this.nota1 = nota1;
	}

	public int getNota2() {
		return nota2;
	}

	public void setNota2(int nota2) {
		this.nota2 = nota2;
	}

	public int getNota3() {
		return nota3;
	}

	public void setNota3(int nota3) {
		this.nota3 = nota3;
	}
	
	public String getData() {
		return data;
	}
	
	public void setData(String data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "Diario [aluno=" + aluno + ", professorResponsavel=" + professorResponsavel + ", numDeFaltas="
				+ numDeFaltas + ", nota1=" + nota1 + ", nota2=" + nota2 + ", nota3=" + nota3 + "]";
	}

}