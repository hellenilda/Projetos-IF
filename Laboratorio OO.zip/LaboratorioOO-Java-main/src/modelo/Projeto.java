package modelo;

public class Projeto {
	private String professorResponsavel;
	private String alunos;
	private String nome;
	private int id;

	public Projeto() {
		super();
	}

	public Projeto(String professorResponsavel, String alunos, String nome, int id) {
		super();
		this.professorResponsavel = professorResponsavel;
		this.alunos = alunos;
		this.nome = nome;
		this.id = id;
	}

	public String getProfessorResponsavel() {
		return professorResponsavel;
	}

	public void setProfessorResponsavel(String professorResponsavel) {
		this.professorResponsavel = professorResponsavel;
	}

	public String getAlunos() {
		return alunos;
	}

	public void setAlunos(String alunos) {
		this.alunos = alunos;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Projeto [professorResponsavel=" + professorResponsavel + ", alunos=" + alunos + ", nome=" + nome
				+ ", id=" + id + "]";
	}

}