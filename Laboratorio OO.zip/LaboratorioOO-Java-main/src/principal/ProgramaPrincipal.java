package principal;

import modelo.*;

/* Grupo: Gabriel de Freitas, Hellen Lima, Júlia Araújo
	PS.: Os atributos não aceitam acento ortográfico
*/

public class ProgramaPrincipal {
	public static void main(String[] args) {
		Professor p1 = new Professor("Ewerthon", "WebII", 2, 202116610);
		Aluno a1 = new Aluno("Julia", "Informatica", 3, 1, 2021166100);
		//Polimorfismo estático:
		Aluno a2 = new Aluno("Kamilly",3,2,2020166101);
		
		//Relação entre objetos: o objeto "webII" coleta o nome do objeto "a1":
		Diario webII = new Diario(a1.getNome(), "Ewerthon", 0, 100, 80, 95,"27/03/2023");
		
		//Polimorfismo dinâmico:
		Funcionario funcionario = new Professor();
		funcionario.trabalho();

		System.out.println(p1.toString());
		System.out.println(a1.toString());
		System.out.println(a2.toString());
		System.out.println(webII.toString());
	}
}