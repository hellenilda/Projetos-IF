-- Tabela Cliente
CREATE TABLE Cliente (
    id number,
    cpf Varchar2(14),
    nomeCompleto Varchar2(100),
    rua Varchar2(80),
    numero number,
    bairro Varchar2(40),
    estado Varchar2(80),
    cep Varchar2(8),
    CONSTRAINT cliente_pk PRIMARY KEY (id)
);

-- Tabela Fornecedor
CREATE TABLE Fornecedor (
    id number,
    cnpj Varchar2(14),
    nome Varchar2(80),
    rua Varchar2(80),
    numero number,
    bairro Varchar2(40),
    estado Varchar2(80),
    cep Varchar2(8),
    CONSTRAINT fornecedor_pk PRIMARY KEY (id)
);

-- Tabela Produto
CREATE TABLE Produto (
    id number,
    nome Varchar2(100),
    marca Varchar2(80),
    categoria Varchar2(80),
    preco number(10, 2),
    fornecedor_id number,
    CONSTRAINT produto_pk PRIMARY KEY (id),
    CONSTRAINT produto_fornecedor_fk FOREIGN KEY (fornecedor_id) REFERENCES Fornecedor(id)
);

CREATE SEQUENCE cliente_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;

CREATE SEQUENCE produto_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;

CREATE SEQUENCE fornecedor_seq
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;