package edu.ifpb.webII.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import edu.ifpb.webII.model.Cliente;
import edu.ifpb.webII.model.service.ClienteService;

@Controller
@RequestMapping("/clientes")
public class ClienteController {

	@Autowired
	private ClienteService clienteService;

	@GetMapping("/cadastrar")
	public String cadastrar(Cliente cliente, ModelMap model) {
		List<Cliente> clientes = clienteService.listarCliente();
		model.addAttribute("clientes", clientes);
		return "/clientes/cadastroCliente";
	}

	@PostMapping("/salvar")
	public String salvar(Cliente cliente, RedirectAttributes attr) {
		if (cliente.getId() == null) {
			clienteService.cadastrarCliente(cliente);
		} else {
			clienteService.atualizarCliente(cliente);
		}
		attr.addFlashAttribute("sucesso", "Cliente salvo com sucesso!");
		return "redirect:/clientes/cadastrar";
	}

	@GetMapping("listar")
	public String listar(ModelMap model) {
		List<Cliente> clientes = clienteService.listarCliente();
		model.addAttribute("clientes", clientes);
		return "/clientes/listaCliente";
	}

	@GetMapping("/editar/{id}")
	public String preEditar(@PathVariable("id") Long id, ModelMap model) {
		Cliente cliente = clienteService.listarCliente(id);
		model.addAttribute("cliente", cliente);
		return "/clientes/cadastroCliente";
	}

	@PostMapping("/editar")
	public String editar(Cliente cliente, RedirectAttributes attr) {
		clienteService.atualizarCliente(cliente);
		attr.addFlashAttribute("sucesso", "Cliente editado com sucesso!");
		return "redirect:/clientes/cadastrar";
	}

	@GetMapping("excluir/{id}")
	public String excluir(@PathVariable("id") Long id, ModelMap model) {
		clienteService.deletarClienteporID(id);
		model.addAttribute("sucesso", "Cliente excluído com sucesso!");
		return listar(model);
	}

}
