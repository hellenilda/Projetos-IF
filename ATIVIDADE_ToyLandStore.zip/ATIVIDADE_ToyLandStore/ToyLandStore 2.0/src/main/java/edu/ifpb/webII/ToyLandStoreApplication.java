package edu.ifpb.webII;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToyLandStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToyLandStoreApplication.class, args);
	}

}
