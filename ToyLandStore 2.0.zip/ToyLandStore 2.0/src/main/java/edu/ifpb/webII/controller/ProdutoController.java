package edu.ifpb.webII.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import edu.ifpb.webII.model.Produto;
import edu.ifpb.webII.model.service.ProdutoService;

@Controller
@RequestMapping("/produtos")
public class ProdutoController {
	
	@Autowired
	private ProdutoService produtoService;
	
	@GetMapping("/cadastrar")
	public String cadastrar(Produto produto, ModelMap model) {
		List<Produto> produtos = produtoService.listarProdutos();
		model.addAttribute("produtos", produtos);
		return "/produtos/cadastroProduto";
	}
	
	@PostMapping("/salvar")
	public String salvar(Produto produto, RedirectAttributes attr) {
		if (produto.getId() == null) {
			produtoService.cadastrarProduto(produto);
		} else {
			produtoService.atualizarProduto(produto);
		}
		attr.addFlashAttribute("sucesso", "Produto salvo com sucesso!");
		return "redirect:/produtos/cadastrar";
	}
	
	@GetMapping("listar")
	public String listar(ModelMap model) {
		List<Produto> produtos = produtoService.listarProdutos();
		model.addAttribute("produtos", produtos);
		return "/produtos/listaProduto";
	}
	
	@GetMapping("/editar")
	public String editar(Produto produto, RedirectAttributes attr) {
		produtoService.atualizarProduto(produto);
		attr.addFlashAttribute("sucesso", "Produto editado com sucesso!");
		return "redirect:/produtos/cadastrar";
	}
	
	@GetMapping("excluir/{id}")
	public String excluir(@PathVariable("id") Long id, ModelMap model) {
		produtoService.deletarProduto(id);
		model.addAttribute("sucesso", "Produto excluído com sucesso!");
		return listar(model);
	}
}
