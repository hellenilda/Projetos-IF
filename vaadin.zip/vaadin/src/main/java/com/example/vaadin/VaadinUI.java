package com.example.vaadin;

import org.springframework.beans.factory.annotation.Autowired;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;

@Route("")
public class VaadinUI extends VerticalLayout {

	@Autowired
    private Service service;

    // Spring irá injetar o serviço automaticamente através do construtor
    public VaadinUI(Service service) {
        this.service = service;

        TextField nome = new TextField("Digite seu nome:");
        Button btnEnviar = new Button("Enviar");

        btnEnviar.addClickListener(evento -> {
            String mensagem = service.bemVindo(nome.getValue());
            Notification.show(mensagem);
        });

        // Adicionando os objetos dos componentes ao layout
        add(nome, btnEnviar);
    }
}
