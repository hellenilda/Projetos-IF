package com.example.vaadin;

import org.springframework.stereotype.Component;

@Component
public class Service {
	
	public String bemVindo(String nome) {
		return "Bem vindo(a), " + nome;
	}
}
