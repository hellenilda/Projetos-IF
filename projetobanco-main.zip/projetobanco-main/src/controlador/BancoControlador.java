package controlador;

import modelo.Banco;

public class BancoControlador {
	
	public BancoControlador() {}
	
	public boolean salvar(String nome, double lucro) {
		Banco banco = new Banco(nome, lucro);
		
		//Seria chamado o salvar do banco de dados.
		//BancoAcesso.save(banco);
		return true;
		
	}
	
	public Banco remover(long id) {
		//Banco bancoConsultado = BancoAcesso.buscar(id);
		//dentro de buscar havera um select no BD, e o resultado
		//sera convertido em um objeto do tipo Banco.
		return null;
	}
	

}
