package teste;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BancoTest {

	@Test
	void test() {
		// Verificando se as Strings são iguais 
		assertEquals("teste", "teste");
		
		// Verificando se as Strings não são iguais 
		assertNotEquals("aaaa", "bbb");
		
		// Verificando se a condição booleana é igual a true
		boolean a, b;
		a = b = true;
		
		assertTrue(a==b);
		
		// Verificando se a condição booleana é igual a false
		b = false;
		assertFalse(a==b);
		
	}

}
